=== Polylang Slug ===
Contributors: grapplerulrich
Requires at least: 3.9
Tested up to: 4.1.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: polylang, single-slug

Allows same slug for multiple languages in Polylang

== Description ==

Allows same slug for multiple languages in Polylang.

== Frequently Asked Questions ==

= What do I need to do to make this work? =
Install the plugin and activate it and that is it.

== Screenshots ==

There is no settings page or visable output.

== Changelog ==

= 0.1.0 - 13 March 2015 =
* Initial release

== Upgrade Notice ==

= 0.1.0 =
* This is the first stable release.